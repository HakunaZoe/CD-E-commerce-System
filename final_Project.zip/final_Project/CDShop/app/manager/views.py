# encoding: utf-8
import math

from flask import  session, redirect, url_for, request, render_template, flash
from .. import db
from ..models import *
from ..utils.permission import admin_required, permisson_required
from sqlalchemy import func
from . import manager

@manager.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        role = request.form.get('role')
        try:
            user = Managers.query.filter_by(username = username, role=role).first()
            if not user:
                flash('User not exists or no permssion, pleaes check!','danger')
                return redirect(url_for('manager.login', **locals()))
            if user and user.password == password:
                session['username'] = username
                session['role'] = user.role
                session['userinfo'] = {'id':user.id, 'phone':user.phoneno, 'email':user.email, 'address':user.address}
                flash('Login successfully, welcome!','success')
                return redirect(url_for('manager.index'))
            else:
                flash('Username and password are not matched or no permssion, failed!','danger')
                return redirect(url_for('manager.login', **locals()))
        except Exception as e:
            print('Error - {}'.format(str(e)))
            return redirect(url_for('manager.login'))
    else:
        return render_template('manager/manager_login.html')

@manager.route('/logout')
def logout():
    session.clear()
    flash('Logout successfully, Welcome back again!','success')
    return redirect(url_for('manager.login'))

@manager.route('/')
@admin_required
def index():
    return render_template('manager/manager_index.html')


########################### Region management ##################################

@manager.route('/regions', defaults={'page':1})
@manager.route('/regions/<int:page>')
@admin_required
def regions(page):
    result_query = Regions.query
    paginate = result_query.order_by(Regions.id).paginate(page, 15)
    print(paginate.items)
    return render_template('manager/regions.html', results = paginate.items, paginate=paginate)


@manager.route('/addregion', methods=['GET','POST'])
@admin_required
def addregion():
    if request.method == 'POST':
        name = request.form.get('name')
        manager_region_id = request.form.get('manager_region_id')
        try: 
            record = Regions.query.filter_by(name = name).first()
            if record:
                flash('The Region exists already, please check！','danger')
                return redirect(url_for('manager.regions'))
            else:
                record = Regions(name=name,
                                manager_region_id=manager_region_id)
                db.session.add(record)
                db.session.commit()
                flash('Region is created successfully!','success')
                return redirect(url_for('manager.regions'))
        except Exception as e:
            print('Exception - {}'.format(str(e)))
            flash('Exception occurred, please try it later!','danger')
            return redirect(url_for('manager.regions'))
    else:
        records = Managers.query.filter_by(role='manager-region').all()
        return render_template('manager/addregion.html', manager_region_list=records)

@manager.route('/delregion/<int:id>', methods=['GET','POST'])
@permisson_required(['manager-region','manager'])
def delregion(id):
    try:

        record = Regions.query.get_or_404(id)
        #db.session.delete(record)
        #db.session.commit()
        flash('You cannot delay a region!!!!','danger!!!')
        return redirect(url_for('manager.regions'))
    except Exception as e:
        print('Exception - {}'.format(str(e)))
        flash('Exception occurred, please try it later!','danger')
        return redirect(url_for('manager.regions'))


@manager.route('/editregion/<int:id>', methods=['GET','POST'])
@permisson_required(['manager-region','manager'])
def editregion(id):
    region = Regions.query.filter_by(id = id).first()
    if request.method == 'POST':
        manager_region_id = request.form.get('manager_region_id')
        try: 
            record = Regions.query.filter_by(id = id).first()
            record.manager_region_id = manager_region_id
            db.session.commit()
            flash('Region is updated successfully!','success')
            return redirect(url_for('manager.regions'))
        except Exception as e:
            print('Exception - {}'.format(str(e)))
            flash('Exception occurred, please try it later!','danger')
            return redirect(url_for('manager.editregion',id=id))
    else:
        records = Managers.query.filter_by(role='manager-region').all()
        return render_template('manager/editregion.html', region=region, manager_region_list=records)

########################### Store management ##################################
@manager.route('/stores', defaults={'page':1})
@manager.route('/stores/<int:page>')
@permisson_required(['manager-region','manager'])
def stores(page):
    result_query = Stores.query
    paginate = result_query.order_by(Stores.id).paginate(page, 15)
    print(paginate.items)
    return render_template('manager/stores.html', results = paginate.items, paginate=paginate)

@manager.route('/addstore', methods=['GET','POST'])
@permisson_required(['manager-region','manager'])
def addstore():
    if request.method == 'POST':
        name = request.form.get('name')
        region_id = request.form.get('region_id')
        manager_store_id = request.form.get('manager_store_id')
        try: 
            record = Stores.query.filter_by(name = name).first()
            if record:
                flash('The Store exists already, please check！','danger')
                return redirect(url_for('manager.stores'))
            else:
                record = Stores(name=name,
                                manager_store_id=manager_store_id,
                                region_id=region_id)
                db.session.add(record)
                db.session.commit()
                flash('Region is created successfully!','success')
                return redirect(url_for('manager.stores'))
        except Exception as e:
            print('Exception - {}'.format(str(e)))
            flash('Exception occurred, please try it later!','danger')
            return redirect(url_for('manager.stores'))
    else:
        regions = Regions.query.all()
        manager_store_list = Managers.query.filter_by(role='manager-store').all()
        return render_template('manager/addstore.html', regions=regions, manager_store_list=manager_store_list)

@manager.route('/delstore/<int:id>', methods=['GET','POST'])
@permisson_required(['manager-region','manager'])
def delstore(id):
    try:
        record = Stores.query.get_or_404(id)
        db.session.delete(record)
        db.session.commit()
        flash('The record was deleted successfully!','success')
        return redirect(url_for('manager.stores'))
    except Exception as e:
        print('Exception - {}'.format(str(e)))
        flash('Exception occurred, please try it later!','danger')
        return redirect(url_for('manager.stores'))


@manager.route('/editstore/<id>', methods=['GET','POST'])
@permisson_required(['manager-region','manager'])
def editstore(id):
    store = Stores.query.filter_by(id = id).first()
    if request.method == 'POST':
        manager_store_id = request.form.get('manager_store_id')
        region_id = request.form.get('region_id')
        name = request.form.get('name')
        try: 
            record = Stores.query.filter_by(id = id).first()
            record.name = name
            record.region_id = region_id
            record.manager_store_id = manager_store_id
            db.session.commit()
            flash('Region is updated successfully!','success')
            return redirect(url_for('manager.stores'))
        except Exception as e:
            print('Exception - {}'.format(str(e)))
            flash('Exception occurred, please try it later!','danger')
            return redirect(url_for('manager.editstore',id=id))
    else:
        regions = Regions.query.all()
        records = Managers.query.filter_by(role='manager-store').all()
        return render_template('manager/editstore.html', store=store, regions=regions, manager_store_list=records)


########################### Product management ##################################
@manager.route('/products', defaults={'page':1})
@manager.route('/products/<int:page>')
@permisson_required(['manager-store','manager-region','manager'])
def products(page):
    result_query = Products.query
    if session.get('role') == 'manager-store':
        result_query = result_query.filter(Products.store_id == session['userinfo']['id'])
    paginate = result_query.order_by(Products.id).paginate(page, 15)
    return render_template('manager/products.html', results = paginate.items, paginate=paginate)


@manager.route('/delproduct/<int:id>', methods=['GET','POST'])
@permisson_required(['manager-store'])
def delproduct(id):
    try:
        record = Products.query.get_or_404(id)
        db.session.delete(record)
        db.session.commit()
        flash('The record was deleted successfully!','success')
        return redirect(url_for('manager.products'))
    except Exception as e:
        print('Exception - {}'.format(str(e)))
        flash('Exception occurred, please try it later!','danger')
        return redirect(url_for('manager.products'))


@manager.route('/addproduct', methods=['GET','POST'])
@permisson_required(['manager-store'])
def addproduct():
    manager_id = session['userinfo']['id']
    store = Stores.query.filter_by(manager_store_id=manager_id).first()
    if request.method == 'POST':
        album_name = request.form.get('album_name')
        artist = request.form.get('artist')
        genre = request.form.get('genre')
        cdformat = request.form.get('cdformat')
        picture = request.form.get('picture') or '/static/images/a1697619781_2.jpeg'
        description = request.form.get('description')
        region_id = request.form.get('region_id')  or store.region_id
        store_id = request.form.get('store_id') or store.id
        price = request.form.get('price')
        stock = request.form.get('stock')
        try: 
            record = Products.query.filter_by(
                            album_name = album_name,
                            cdformat = cdformat,
                            store_id = store_id
                            ).first()
            if record:
                flash('The Product exists already, please check！','danger')
                return redirect(url_for('manager.products'))
            else:
                record = Products(
                                album_name = album_name,
                                artist = artist,
                                genre = genre,
                                cdformat = cdformat,
                                picture = picture,
                                description = description,
                                region_id = region_id,
                                store_id = store_id,
                                price = price,
                                stock = stock  
                )
                db.session.add(record)
                db.session.commit()
                flash('Product is created successfully!','success')
                return redirect(url_for('manager.products'))
        except Exception as e:
            print('Exception - {}'.format(str(e)))
            flash('Exception occurred, please try it later!','danger')
            return redirect(url_for('manager.addproduct'))
    else:
        return render_template('manager/addproduct.html', store=store)

@manager.route('/editproduct/<id>', methods=['GET','POST'])
@permisson_required(['manager-store'])
def editproduct(id):
    manager_id = session['userinfo']['id']
    store = Stores.query.filter_by(manager_store_id=manager_id).first()
    record = Products.query.filter_by(id = id).first()
    if request.method == 'POST':
        album_name = request.form.get('album_name')
        artist = request.form.get('artist')
        genre = request.form.get('genre')
        cdformat = request.form.get('cdformat')
        picture = request.form.get('picture') or record.picture
        description = request.form.get('description')
        price = request.form.get('price')
        stock = request.form.get('stock')
        try: 
            record.album_name = album_name
            record.artist = artist
            record.genre = genre
            record.cdformat = cdformat
            record.picture = picture
            record.description = description
            record.price = price
            record.stock = stock
            db.session.commit()
            flash('Product is updated successfully!','success')
            return redirect(url_for('manager.products'))
        except Exception as e:
            print('Exception - {}'.format(str(e)))
            flash('Exception occurred, please try it later!','danger')
            return redirect(url_for('manager.editproduct',id=id))
    else:
        return render_template('manager/editproduct.html', store=store, record=record)


@manager.route('/transactios', methods=['GET'])
@permisson_required(['manager-store','manager-region','manager'])
def transactions():
    try:
        if session.get('role') == 'manager-store':
            stores = Stores.query.filter_by(manager_store_id = session['userinfo']['id']).all()
            store_ids = [store.id for store in stores]
            results = Transactions.query.join(Products, Transactions.product_id==Products.id).filter(Transactions.store_id.in_(store_ids)).add_entity(Products).all()
        else:
            results = Transactions.query.join(Products, Transactions.product_id==Products.id).add_entity(Products).all()

        for result in results:
            print(result.Products.album_name)
        return render_template('manager/transactions.html', results=results)
    except Exception as e:
        print('Exception: {}'.format(e))
        return redirect(url_for('manager.products'))

################## Analysic #########################
@manager.route('/total_per_day', methods=['GET'])
@permisson_required(['manager'])
def total_per_day():
    try:
        region_name = 'All Region'
        if session.get('role') == "manager-region":
            region_id=session['userinfo']['id']
            region = Regions.query.filter_by(id = region_id).first()
            if region:
                region_name = region.name
            results = Transactions.query.with_entities(
                                    Transactions.trandate, func.sum(Transactions.total_cost).label('total_cost')
                                    ).filter_by(region_id=session['userinfo']['id']
                                    ).group_by(Transactions.trandate).order_by(Transactions.trandate.desc()).all()
        else:
            results = Transactions.query.with_entities(
                                    Transactions.trandate, func.sum(Transactions.total_cost).label('total_cost')
                                    ).group_by(Transactions.trandate).order_by(Transactions.trandate.desc()).all()
            print('sdlkfjslkdfjlskdfsdfsdfsdf')
            for result in results:
                print(type(result[1]))

        return render_template('manager/total_per_day.html', results=results, region_name=region_name)
    except Exception as e:
        print('Exception: {}'.format(e))
        return redirect(url_for('manager.products'))
