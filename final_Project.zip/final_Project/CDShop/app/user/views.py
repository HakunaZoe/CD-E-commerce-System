# encoding: utf-8
from flask import  session, redirect, url_for, request, render_template, flash
from .. import db
from ..models import *
from . import user

@user.route('/login', methods=['POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        role = request.form.get('role')
        try:
            if role == 'business':
                user = CustomerBusiness.query.filter_by(username=username).first()
            else:
                user = CustomerHome.query.filter_by(username=username).first()
            if user is not None and user.password == password:
                session['username'] = username
                session['userinfo'] = {'id': user.id, 'phone': user.phoneno, 'email': user.email, 'address': user.address}
                session['role'] = role
                flash('Login successfully!','success')
                return redirect(url_for('product.index'))
            else:
                session.clear()
                print('Username and password are not matched, failed!','danger')
                return redirect(url_for('product.index'))
        except Exception as e:
            print('Error - {}'.format(str(e)))
            flash('Login failed, please check with admin!','danger')
            return redirect(url_for('product.index'))
    else:
        return redirect(url_for('product.index'))


import re

@user.route('/register', methods=['POST'])#注册路由
def register():
    error=None
    if request.method == 'POST':#从表单取数据
        role = request.form.get('role')
        username = request.form.get('username')
        password = request.form.get('password')
        password2 = request.form.get('password2')
        email = request.form.get('email')
        phoneno = request.form.get('phoneno')
        address = request.form.get('address')
        message_wrong=False;
        #验证用户名
        if len(username) < 3 and len(username) > 15:
            return'用户信息输入错误'
            flash('Error-username error','danger')

            message_wrong=True;
        #验证密码-两次相等且包含大小写和数字
        if len(password)<6 or re.match(r'^[0-9A-Za-z]{6,20}$', password)==None or password != password2:
            flash('Error - password is invalid!','danger')

            message_wrong=True;
        #验证邮箱
        if re.match("^.+\\@(\\[?)[a-zA-Z0-9\\-\\.]+\\.([a-zA-Z]{2,3}|[0-9]{1,3})(\\]?)$", email) == None:
            flash('Error - email format error','danger')

            message_wrong=True;
        #验证手机号
        if len(phoneno)<10 or re.match('(?=.*[A-Z])(?=.*[a-z])',phoneno)!=None:

            flash('Error-phone number is illegal','danger')
            message_wrong=True;
        if message_wrong==True:
            return redirect(url_for('product.index'))
        if role == 'business':
            category = request.form.get('category')
            company_income = request.form.get('company_income')
            try: 
                user = CustomerBusiness.query.filter_by(username = username).first()
                if user:
                    print('Error - The user exits already！')
                    return redirect(url_for('product.index'))
                else:
                    user = CustomerBusiness(username=username,
                                            password=password,
                                            email = email,
                                            phoneno = phoneno,
                                            address = address,
                                            category = category,
                                            company_income = company_income
                                        )
                    db.session.add(user)#请求上下文对象，封装用户信息
                    db.session.commit()#加入数据失败的话要加入回滚？不理解
                    flash('User is created successfully, please login!','success')
                    return redirect(url_for('product.index'))
            except Exception as e:
                print('Exception - {}'.format(str(e)))
                flash('Exception occuried!','danger')
                return redirect(url_for('product.index'))
        elif role == 'home':
            marriage_status = request.form.get('marriage_status')
            age = request.form.get('age')
            gender = request.form.get('gender')
            income = request.form.get('income')
            try: 
                user = CustomerHome.query.filter_by(username = username).first()
                if user:
                    flash('Info - The user exits already！','danger')
                    return redirect(url_for('product.index'))
                else:
                    user = CustomerHome(username=username,
                                            password=password,
                                            email = email,
                                            phoneno = phoneno,
                                            address = address,
                                            marriage_status = marriage_status,
                                            age = age,
                                            gender = gender,
                                            income = income
                                        )
                    db.session.add(user)
                    db.session.commit()
                    flash('User is created successfully, please login!','success')
                    return redirect(url_for('product.index'))
            except Exception as e:
                print('Exception - {}'.format(str(e)))
                flash('Exception occuried!','danger')
                return redirect(url_for('product.index'))
    else:
        return redirect(url_for('product.index'))

@user.route('/logout')
def logout():
    session.clear()
    flash('Logout successfully, Welcome back again!','success')
    return redirect(url_for('product.index'))

@user.route('/update', methods=['POST'])#注册路由
def update():
    if request.method == 'POST':#从表单取数据
        role = request.form.get('role')
        username = request.form.get('username')
        password = request.form.get('password')
        password2 = request.form.get('password2')
        email = request.form.get('email')
        phoneno = request.form.get('phoneno')
        address = request.form.get('address')
        message_wrong=False;
        #验证用户名
        if len(username) < 3 and len(username) > 15:
            flash('Error-username error','danger')
            message_wrong=True;
        #验证密码-两次相等且包含大小写和数字
        if len(password)<6 or re.match(r'^[0-9A-Za-z]{6,20}$', password)==None or password != password2:
            flash('Error - password is illegal!','danger')
            message_wrong=True;
        #验证邮箱
        if re.match("^.+\\@(\\[?)[a-zA-Z0-9\\-\\.]+\\.([a-zA-Z]{2,3}|[0-9]{1,3})(\\]?)$", email) == None:
            flash('Error - email format error','danger')
            message_wrong=True;
        #验证手机号
        if len(phoneno)<10 or re.match('(?=.*[A-Z])(?=.*[a-z])',phoneno)!=None:
            flash('Error-phone number is illegal','danger')
            message_wrong=True;
        if message_wrong==True:
            return redirect(url_for('product.index'))
        if role == 'business':
            category = request.form.get('category')
            company_income = request.form.get('company_income')
            try:
                user = CustomerBusiness.query.filter_by(username = username).first()
                if user:
                    print('Error - The user exits already！')
                    return redirect(url_for('product.index'))
                else:
                    user = CustomerBusiness(username=username,
                                            password=password,
                                            email = email,
                                            phoneno = phoneno,
                                            address = address,
                                            category = category,
                                            company_income = company_income
                                        )
                    db.session.add(user)#请求上下文对象，封装用户信息
                    db.session.commit()
                    flash('User is created successfully, please login!','success')
                    return redirect(url_for('product.index'))
            except Exception as e:
                print('Exception - {}'.format(str(e)))
                flash('Exception occuried!','danger')
                return redirect(url_for('product.index'))
        elif role == 'home':
            marriage_status = request.form.get('marriage_status')
            age = request.form.get('age')
            gender = request.form.get('gender')
            income = request.form.get('income')
            try:
                user = CustomerHome.query.filter_by(username = username).first()
                if user:
                    flash('Info - The user exits already！','danger')
                    return redirect(url_for('product.index'))
                else:
                    user = CustomerHome(username=username,
                                            password=password,
                                            email = email,
                                            phoneno = phoneno,
                                            address = address,
                                            marriage_status = marriage_status,
                                            age = age,
                                            gender = gender,
                                            income = income
                                        )
                    db.session.add(user)
                    db.session.commit()
                    flash('information  updated!!!','success')
                    return redirect(url_for('product.index'))
            except Exception as e:
                print('Exception - {}'.format(str(e)))
                flash('Exception occuried!','danger')
                return redirect(url_for('product.index'))
    else:
        return redirect(url_for('product.index'))