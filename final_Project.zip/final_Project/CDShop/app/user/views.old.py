# encoding: utf-8
from flask import  session, redirect, url_for, request, render_template, flash
from .. import db
from ..models import *
from . import user

@user.route('/login', methods=['POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        role = request.form.get('role')

        try:
            if role == 'business':
                user = CustomerBusiness.query.filter_by(username = username).first()
            else:
                user = CustomerHome.query.filter_by(username = username).first()
            if user is not None and user.password == password:
                session['username'] = username
                session['userinfo'] = {'id':user.id, 'phone':user.phoneno, 'email':user.email, 'address':user.address}
                session['role'] = role
                flash('Login successfully!','success')
                return redirect(url_for('product.index'))
            else:
                session.clear()
                print('Username and password are not matched, failed!','danger')
                return redirect(url_for('product.index'))
        except Exception as e:
            print('Error - {}'.format(str(e)))
            flash('Login failed, please check with admin!','danger')
            return redirect(url_for('product.index'))
    else:
        return redirect(url_for('product.index'))


@user.route('/register', methods=['POST'])
def register():
    if request.method == 'POST':
        role = request.form.get('role')
        username = request.form.get('username')
        password = request.form.get('password')
        password2 = request.form.get('password2')
        email = request.form.get('email')
        phoneno = request.form.get('phoneno')
        address = request.form.get('address')
        if password != password2:
            print('Error - two password not matched!','danger')
            return redirect(url_for('product.index'))

        if role == 'business':
            category = request.form.get('category')
            company_income = request.form.get('company_income')
            try: 
                user = CustomerBusiness.query.filter_by(username = username).first()
                if user:
                    print('Error - The user exits already！')
                    return redirect(url_for('product.index'))
                else:
                    user = CustomerBusiness(username=username,
                                            password=password,
                                            email = email,
                                            phoneno = phoneno,
                                            address = address,
                                            category = category,
                                            company_income = company_income
                                        )
                    db.session.add(user)
                    db.session.commit()
                    flash('User is created successfully, please login!','success')
                    return redirect(url_for('product.index'))
            except Exception as e:
                print('Exception - {}'.format(str(e)))
                flash('Exception occuried!','danger')
                return redirect(url_for('product.index'))
        elif role == 'home':
            marriage_status = request.form.get('marriage_status')
            age = request.form.get('age')
            gender = request.form.get('gender')
            income = request.form.get('income')
            try: 
                user = CustomerHome.query.filter_by(username = username).first()
                if user:
                    flash('Info - The user exits already！','danger')
                    return redirect(url_for('product.index'))
                else:
                    user = CustomerHome(username=username,
                                            password=password,
                                            email = email,
                                            phoneno = phoneno,
                                            address = address,
                                            marriage_status = marriage_status,
                                            age = age,
                                            gender = gender,
                                            income = income
                                        )
                    db.session.add(user)
                    db.session.commit()
                    flash('User is created successfully, please login!','success')
                    return redirect(url_for('product.index'))
            except Exception as e:
                print('Exception - {}'.format(str(e)))
                flash('Exception occuried!','danger')
                return redirect(url_for('product.index'))
    else:
        return redirect(url_for('product.index'))

@user.route('/logout')
def logout():
    session.clear()
    flash('Logout successfully, Welcome back again!','success')
    return redirect(url_for('product.index'))

