from flask import Flask, redirect, url_for
from config import config

from flask_sqlalchemy import SQLAlchemy
db = SQLAlchemy(use_native_unicode='utf8')
from .models import *

def create_app(config_name):
    app = Flask(__name__)
    db.init_app(app)

    try:
        app.config.from_object(config[config_name])
        config[config_name].init_app(app)
    except Exception as e:
        print('config {}'.format(app.config))
        print(e)

    @app.route("/")
    def index():
        return redirect(url_for('product.index'))

    from .product import product as product_blueprint
    app.register_blueprint(product_blueprint, url_prefix='/product')

    from .user import user as user_blueprint
    app.register_blueprint(user_blueprint, url_prefix='/user')

    from .manager import manager as manager_blueprint
    app.register_blueprint(manager_blueprint, url_prefix='/manager')

    return app
