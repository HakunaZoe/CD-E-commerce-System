# encoding: utf-8
from flask import Flask, session, request, flash, session, flash

def addBasket():
    product_id = request.args.get('id')
    if 'basket' in session:
        basket = session['basket']
        if product_id in basket:
            basket[product_id] = basket[product_id] + 1
        else:
            basket[product_id] = 1
    else:
        basket = {product_id: 1}
    session['basket'] = basket
    print(session['basket'])
    flash('Product is added into basket successfully!','success')

def reduceBasket():
    product_id = request.args.get('id')
    if 'basket' in session:
        basket = session['basket']
        if product_id in basket:
            basket[product_id] = basket[product_id] - 1
            if basket[product_id] == 0:
                del basket[product_id]
                flash('The Product was removed basket successfully!','success')
    else:
        basket = {}
    session['basket'] = basket
    flash('Product is removed from basket successfully!','success')

def delBasket():
    product_id = request.args.get('id')
    if 'basket' in session:
        basket = session['basket']
        if product_id in basket:
            del basket[product_id]
            flash('The products are removed from basket successfully!','success')
    else:
        basket = {}
    session['basket'] = basket


def delAllBasket():
    basket = {}
    session['basket'] = basket
    flash('basket are cleaned successfully!','success')
