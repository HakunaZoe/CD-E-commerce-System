# encoding: utf-8
from flask import  session, flash, session, flash, redirect, url_for
from functools import wraps

def login_required(func):
    @wraps(func)
    def inner(*args, **kwargs):
        if not 'username' in session:
            flash('Please login firstly!', 'danger')
            return redirect(url_for('product.index'))
        return func(*args, **kwargs)
    return inner

def admin_required(func):
    @wraps(func)
    def inner(*args, **kwargs):
        if 'role' in session and session['role'] in ['manager','manager-region','manager-store']:
            pass
        else:
            flash('Please login firstly!', 'danger')
            return redirect(url_for('manager.login'))
        return func(*args, **kwargs)
    return inner

def permisson_required(permission):
    def check_permission(func):
        @wraps(func)
        def inner(*args, **kwargs):
            if 'role' in session and session['role'] in permission:
                pass
            else:
                flash('You do not have permission, plsease contact manager!', 'danger')
                return redirect(url_for('manager.index'))
            return func(*args, **kwargs)
        return inner
    return check_permission