# encoding: utf-8
from flask import  session, redirect, url_for, request, render_template, current_app, flash
from ..utils import mainfunc
from ..utils.permission import login_required
from .. import db
from ..models import *
from datetime import datetime
from . import product

@product.route('/', defaults={'page':1})
@product.route('/page/<int:page>')
def index(page):
    try:
        region_id = request.args.get('region_id') or 1
        qkey = request.args.get('qkey')
        genre = request.args.get('genre')

        product_query = Products.query
        if region_id:
            product_query  = product_query.filter(Products.region_id == region_id)
        if qkey:
            product_query  = product_query.filter(Products.album_name.ilike("%{}%".format(qkey)))
        if genre:
            product_query  = product_query.filter(Products.genre == genre)

        paginate = product_query.order_by(Products.id).paginate(page, 12)
        print(paginate.items)
        return render_template('product.html', results = paginate.items, paginate=paginate)
    except Exception as e:
        print('Exception: {}'.format(e))
        flash('Exception occuried! {}'.format(e))
        return render_template('product.html', results = [])

@product.route('/detail/<id>')
def detail(id):
    try:
        result = Products.query.get_or_404(id)
        print(result)
        return render_template('detail.html', result = result)
    except Exception as e:
        print(e)
        flash('Exception occuried!')
        return render_template('index.html', result = [])

@product.route('/basket')
@login_required
def basket():
    if 'basket' in session:
        basket = session['basket']
        productid_list = list(basket.keys())
        productid_list = [int(productid) for productid in productid_list]
        # print(productid_list)
        try:
            results = Products.query.filter(Products.id.in_(productid_list)).all()
            total = 0
            for item in results:
                print(item.id)
                total = total + item.price * basket[str(item.id)]
            return render_template('basket.html', results = results, basket=basket, total = total)
        except Exception as e:
            print('Excepiton: {}'.format(e))
            return render_template('basket.html', results=[])
    else:
        return render_template('basket.html', results=[])

@product.route('/addbasket')
@login_required
def addToBasket():
    mainfunc.addBasket()
    return redirect(url_for('product.index'))

@product.route('/add')
@login_required
def add():
    mainfunc.addBasket()
    return redirect(url_for('product.basket'))

@product.route('/reduce')
@login_required
def rBasket():
    mainfunc.reduceBasket()
    return redirect(url_for('product.basket'))

@product.route('/delete')
@login_required
def deleteBasket():
    mainfunc.delBasket()
    return redirect(url_for('product.basket'))

@product.route('/deleteall')
@login_required
def deleteAllBasket():
    mainfunc.delAllBasket()
    return redirect(url_for('product.basket'))

@product.route('/checkout', methods=['GET','POST'])
@login_required
def checkout():
    if request.method == 'GET':
        if 'basket' in session:
            total = request.args.get('total')
            return render_template('checkout.html', total = total)
        else:
            return render_template('checkout.html', total = 0)
    else:
        total = request.form.get('total')
        if total == 0:
            flash('No need to check!','info')
            return redirect(url_for('product.index'))

        basket = session['basket']
        productid_list = list(basket.keys())
        productid_list = [int(productid) for productid in productid_list]
        try:
            products = Products.query.filter(Products.id.in_(productid_list)).all()
            for product in products:
                product.stock -= basket[str(product.id)]
                db.session.commit()
                total = round(product.price * basket[str(product.id)],2)
                transaction = Transactions(product_id=product.id,
                                            cdformat=product.cdformat,
                                            customer_id=session['userinfo']['id'],
                                            region_id = product.region_id,
                                            store_id = product.store_id,
                                            count = basket[str(product.id)],
                                            total_cost = total,
                                            trandate = datetime.now().strftime('%Y-%m-%d')
                                        )
                db.session.add(transaction)
                db.session.commit()
            mainfunc.delAllBasket()
            flash('Thanks for ordering the product, we will deliver the product ASAP!','success')
            return redirect(url_for('product.index'))
        except Exception as e:
            flash('Exception occurred, please contact admin!','danger')
            return redirect(url_for('product.checkout'))

@product.route('/transaction', methods=['GET'])
@login_required
def transaction():
    try:
        # results = Transactions.query.filter(Transactions.customer_id == session['userinfo']['id']).all()
        if session['role'] in ['business','home']:
            results = Transactions.query.join(Products, Transactions.product_id==Products.id).add_entity(Products).filter(Transactions.customer_id == session['userinfo']['id']).all()
        else:
            results = Transactions.query.join(Products, Transactions.product_id==Products.id).add_entity(Products).all()
        for result in results:
            print(result.Products.album_name)
        return render_template('transaction.html', results=results)
    except Exception as e:
        print('Exception: {}'.format(e))
        return redirect(url_for('product.transaction'))