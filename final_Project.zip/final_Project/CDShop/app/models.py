from enum import unique

from sqlalchemy.orm import defaultload
from app import db
from datetime import datetime

class CustomerBusiness(db.Model,):
    """Model for Customer Business users."""
    __tablename__ = 'customers_business'
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(100), unique=True)
    password = db.Column(db.String(20))
    email = db.Column(db.String(100), unique=True)
    address = db.Column(db.String(100))  
    phoneno = db.Column(db.String(100))
    category = db.Column(db.String(100))
    company_income = db.Column(db.Float)
    role = db.Column(db.String(20), default='business')

class CustomerHome(db.Model,):
    """Model for Customer Home."""
    __tablename__ = 'customers_home'
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(100), unique=True)
    password = db.Column(db.String(20))
    email = db.Column(db.String(100), unique=True)
    address = db.Column(db.String(100))  
    phoneno = db.Column(db.String(100))
    marriage_status = db.Column(db.String(100))
    age = db.Column(db.Integer)
    gender = db.Column(db.String(100))
    income = db.Column(db.Float)
    role = db.Column(db.String(20), default='home')

class Managers(db.Model,):
    """Model for users."""
    __tablename__ = 'managers'
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(100))
    password = db.Column(db.String(20))
    email = db.Column(db.String(100))
    address = db.Column(db.String(100))  
    phoneno = db.Column(db.String(100))
    role = db.Column(db.String(100))
    region = db.Column(db.String(100))
    store = db.Column(db.String(100))
    

class Regions(db.Model,):
    """Model for regions."""
    __tablename__ = 'regions'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), unique=True)
    manager_region_id = db.Column(db.Integer)
    stores = db.relationship("Stores", backref="regions")
    products = db.relationship("Products", backref="products1")

class Stores(db.Model,):
    """Model for stores."""
    __tablename__ = 'stores'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), unique=True)
    manager_store_id = db.Column(db.String(100))
    region_id=db.Column(db.Integer, db.ForeignKey('regions.id'))
    products = db.relationship("Products", backref="products2")


class Products(db.Model,):
    """Model for users."""
    __tablename__ = 'products'
    id = db.Column(db.Integer, primary_key=True)
    album_name = db.Column(db.String(100))
    artist = db.Column(db.String(100))
    genre = db.Column(db.String(100))
    cdformat = db.Column(db.String(20))  
    picture = db.Column(db.String(200))
    description = db.Column(db.String(1000))
    region_id = db.Column(db.Integer, db.ForeignKey('regions.id'))
    store_id = db.Column(db.Integer, db.ForeignKey('stores.id'))
    price = db.Column(db.Float)
    stock = db.Column(db.Integer)

class Transactions(db.Model,):
    """Model for users."""
    __tablename__ = 'transactions'
    id = db.Column(db.Integer, primary_key=True)
    product_id = db.Column(db.String(100))
    cdformat = db.Column(db.String(20))
    customer_id = db.Column(db.Integer)  
    region_id = db.Column(db.Integer)
    store_id = db.Column(db.Integer)
    count = db.Column(db.Integer)
    total_cost = db.Column(db.Float)
    trandate = db.Column(db.String(30))
