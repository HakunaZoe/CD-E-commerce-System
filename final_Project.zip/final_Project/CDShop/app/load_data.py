# -*- coding:utf-8 -*-
import pandas as pd
import pymysql
import time, datetime


def get_data(file_name):
    # 用pandas读取csv
    # data = pd.read_csv(file_name,engine='python',encoding='gbk')
    data = pd.read_csv(file_name, engine='python')
    # 数据库连接
    conn = pymysql.connect(
        user="Hakuna",
        port=3306,
        passwd="Zyj2000317@",
        db="ecommercecd",
        host="localhost",
        charset='utf8'
    )

    # 使用cursor()方法获取操作游标
    cursor = conn.cursor()

    # 数据过滤，替换 nan 值为 None
    data = data.astype(object).where(pd.notnull(data), None)

    for id,album_name,artist,genre,cdformat,picture,description,region_id,store_id,price,stock in zip(
            data['id'], data['album_name'], data['artist'], data['genre'],
            data['cdformat'], data['picture'], data['description'], data['region_id'],
            data['store_id'], data['price'],data['stock']):

        dataList = [id,album_name,artist,genre,cdformat,picture,description,region_id,store_id,price,stock]

        print(dataList)  # 插入的值

        try:
            insertsql = "INSERT INTO ecommercecd.products(id,album_name,artist,genre,cdformat,picture,description,region_id,store_id,price,stock) VALUES(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"
            cursor.execute(insertsql, dataList)
            conn.commit()
        except Exception as e:
            print("Exception")
            print(e)
            conn.rollback()

    cursor.close()
    # 关闭数据库连接
    conn.close()


def main():
    # 读取数据
    get_data(r'C:\Users\DELL\Desktop\Database management\CDShop_v2.1\CDShop\data.csv')


if __name__ == '__main__':
    main()

