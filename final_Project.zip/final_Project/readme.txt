-----------Final project of INFSCI 2710:Database Management Fall 2021,University of Pittsburgh------

After the demo demonstration, some details of the system have been improved:
	(1)Changed the system prompts, such that user can directly change the error message in the registration interface without returning to the main interface
	(2)Changed the system prompts,such that users can know in advance when the selected goods are sold out
	(3)Changed some words choice 
	(4)Modified the manager's permissions
	(5)Be more user-friendly

Group members:
Yutong Zhang           yuz192@pitt.edu
Enmin   Li                   enl29@pitt.edu
Yijun     Zhou             yiz209@pitt.edu
